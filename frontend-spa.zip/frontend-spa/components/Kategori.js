const KategoriComponent = {
  template: `
  <div class="p-6">
    <div class="flex justify-between items-center mb-4">
      <h2 class="text-2xl font-bold text-gray-700">🗂️ Kategori</h2>
      <button @click="openModal()" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">+ Tambah</button>
    </div>
    <div class="bg-white rounded-xl shadow overflow-x-auto">
      <table class="w-full text-sm">
        <thead class="bg-blue-600 text-white">
          <tr><th class="p-3 text-left">No</th><th class="p-3 text-left">Nama Kategori</th><th class="p-3 text-left">Deskripsi</th><th class="p-3 text-left">Aksi</th></tr>
        </thead>
        <tbody>
          <tr v-for="(item, i) in list" :key="item.id" class="border-b hover:bg-gray-50">
            <td class="p-3">{{ i+1 }}</td>
            <td class="p-3">{{ item.nama_kategori }}</td>
            <td class="p-3">{{ item.deskripsi }}</td>
            <td class="p-3 flex gap-2">
              <button @click="openModal(item)" class="bg-yellow-400 text-white px-3 py-1 rounded hover:bg-yellow-500">Edit</button>
              <button @click="hapus(item.id)" class="bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600">Hapus</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
    <!-- Modal -->
    <div v-if="modal" class="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div class="bg-white rounded-xl p-6 w-full max-w-md shadow-xl">
        <h3 class="text-lg font-bold mb-4">{{ form.id ? 'Edit' : 'Tambah' }} Kategori</h3>
        <div class="mb-3">
          <label class="block text-sm font-medium mb-1">Nama Kategori</label>
          <input v-model="form.nama_kategori" class="w-full border rounded-lg px-3 py-2"/>
        </div>
        <div class="mb-4">
          <label class="block text-sm font-medium mb-1">Deskripsi</label>
          <textarea v-model="form.deskripsi" class="w-full border rounded-lg px-3 py-2"></textarea>
        </div>
        <div class="flex gap-2 justify-end">
          <button @click="modal=false" class="px-4 py-2 border rounded-lg">Batal</button>
          <button @click="simpan" class="bg-blue-600 text-white px-4 py-2 rounded-lg">Simpan</button>
        </div>
      </div>
    </div>
  </div>`,
  data() {
    return { list: [], modal: false, form: { id: null, nama_kategori: '', deskripsi: '' } };
  },
  mounted() { this.load(); },
  methods: {
    async load() {
      const r = await axios.get('http://localhost/UAS_WEB2/ci4/public/api/kategori');
      this.list = r.data.data;
    },
    openModal(item = null) {
      this.form = item ? { ...item } : { id: null, nama_kategori: '', deskripsi: '' };
      this.modal = true;
    },
    async simpan() {
      if (this.form.id) await axios.put(`http://localhost/UAS_WEB2/ci4/public/api/kategori/${this.form.id}`, this.form);
      else await axios.post('http://localhost/UAS_WEB2/ci4/public/api/kategori', this.form);
      this.modal = false; this.load();
    },
    async hapus(id) {
      if (confirm('Hapus kategori ini?')) {
        await axios.delete(`http://localhost/UAS_WEB2/ci4/public/api/kategori/${id}`);
        this.load();
      }
    }
  }
};