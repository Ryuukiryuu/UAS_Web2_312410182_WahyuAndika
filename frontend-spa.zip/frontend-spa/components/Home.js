const HomeComponent = {
  template: `
  <div class="min-h-screen bg-gradient-to-br from-blue-600 to-blue-900 flex flex-col items-center justify-center text-white px-4">
    <h1 class="text-4xl font-bold mb-2">📦 E-Inventory</h1>
    <p class="text-blue-200 mb-8">Sistem Manajemen Inventaris Barang</p>
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
      <div class="bg-white/20 rounded-xl p-4 text-center">
        <div class="text-3xl font-bold">{{ summary.total_barang }}</div>
        <div class="text-sm text-blue-200">Total Barang</div>
      </div>
      <div class="bg-white/20 rounded-xl p-4 text-center">
        <div class="text-3xl font-bold">{{ summary.total_kategori }}</div>
        <div class="text-sm text-blue-200">Kategori</div>
      </div>
      <div class="bg-white/20 rounded-xl p-4 text-center">
        <div class="text-3xl font-bold">{{ summary.total_supplier }}</div>
        <div class="text-sm text-blue-200">Supplier</div>
      </div>
      <div class="bg-white/20 rounded-xl p-4 text-center">
        <div class="text-3xl font-bold">{{ summary.total_histori }}</div>
        <div class="text-sm text-blue-200">Histori</div>
      </div>
    </div>
    <router-link to="/login" class="bg-white text-blue-700 font-semibold px-6 py-2 rounded-full hover:bg-blue-50">
      Login Admin →
    </router-link>
  </div>`,
  data() {
    return { summary: { total_barang: 0, total_kategori: 0, total_supplier: 0, total_histori: 0 } };
  },
  mounted() {
    axios.get('http://localhost/UAS_WEB2/ci4/public/api/summary')
      .then(r => this.summary = r.data.data);
  }
};