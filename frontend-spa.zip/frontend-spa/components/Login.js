const LoginComponent = {
  template: `
  <div class="min-h-screen bg-gray-100 flex items-center justify-center">
    <div class="bg-white rounded-2xl shadow-lg p-8 w-full max-w-sm">
      <h2 class="text-2xl font-bold text-center text-blue-700 mb-6">🔐 Login Admin</h2>
      <div v-if="error" class="bg-red-100 text-red-600 text-sm rounded p-2 mb-4">{{ error }}</div>
      <div class="mb-4">
        <label class="block text-sm font-medium text-gray-700 mb-1">Username</label>
        <input v-model="form.username" type="text" class="w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-400" placeholder="admin"/>
      </div>
      <div class="mb-6">
        <label class="block text-sm font-medium text-gray-700 mb-1">Password</label>
        <input v-model="form.password" type="password" class="w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-400" placeholder="••••••"/>
      </div>
      <button @click="login" :disabled="loading" class="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 font-semibold">
        {{ loading ? 'Memproses...' : 'Login' }}
      </button>
    </div>
  </div>`,
  data() {
    return { form: { username: '', password: '' }, error: '', loading: false };
  },
  methods: {
    async login() {
      this.loading = true; this.error = '';
      try {
        const r = await axios.post('http://localhost/UAS_WEB2/ci4/public/api/login', this.form);
        localStorage.setItem('token', r.data.token);
        localStorage.setItem('isLoggedIn', true);
        localStorage.setItem('username', r.data.username);
        this.$router.push('/dashboard');
      } catch (e) {
        this.error = e.response?.data?.message || 'Login gagal';
      } finally { this.loading = false; }
    }
  }
};