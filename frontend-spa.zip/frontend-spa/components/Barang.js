const BarangComponent = {
  template: `
  <div class="p-6">
    <div class="flex justify-between items-center mb-4">
      <h2 class="text-2xl font-bold text-gray-700">📦 Barang</h2>
      <button @click="openModal()" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">+ Tambah</button>
    </div>
    <div class="bg-white rounded-xl shadow overflow-x-auto">
      <table class="w-full text-sm">
        <thead class="bg-blue-600 text-white">
          <tr>
            <th class="p-3 text-left">No</th><th class="p-3 text-left">Kode</th>
            <th class="p-3 text-left">Nama Barang</th><th class="p-3 text-left">Stok</th>
            <th class="p-3 text-left">Harga</th><th class="p-3 text-left">Kategori</th>
            <th class="p-3 text-left">Supplier</th><th class="p-3 text-left">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(item, i) in list" :key="item.id" class="border-b hover:bg-gray-50">
            <td class="p-3">{{ i+1 }}</td>
            <td class="p-3">{{ item.kode_barang }}</td>
            <td class="p-3">{{ item.nama_barang }}</td>
            <td class="p-3">
              <span :class="item.stok < 5 ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-600'" class="px-2 py-1 rounded-full text-xs font-semibold">
                {{ item.stok }}
              </span>
            </td>
            <td class="p-3">Rp {{ Number(item.harga).toLocaleString('id-ID') }}</td>
            <td class="p-3">{{ item.nama_kategori }}</td>
            <td class="p-3">{{ item.nama_supplier }}</td>
            <td class="p-3 flex gap-2">
              <button @click="openModal(item)" class="bg-yellow-400 text-white px-3 py-1 rounded hover:bg-yellow-500">Edit</button>
              <button @click="hapus(item.id)" class="bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600">Hapus</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
    <div v-if="modal" class="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div class="bg-white rounded-xl p-6 w-full max-w-md shadow-xl">
        <h3 class="text-lg font-bold mb-4">{{ form.id ? 'Edit' : 'Tambah' }} Barang</h3>
        <div class="grid grid-cols-2 gap-3 mb-3">
          <div>
            <label class="block text-sm font-medium mb-1">Kode Barang</label>
            <input v-model="form.kode_barang" class="w-full border rounded-lg px-3 py-2"/>
          </div>
          <div>
            <label class="block text-sm font-medium mb-1">Nama Barang</label>
            <input v-model="form.nama_barang" class="w-full border rounded-lg px-3 py-2"/>
          </div>
          <div>
            <label class="block text-sm font-medium mb-1">Stok</label>
            <input v-model="form.stok" type="number" class="w-full border rounded-lg px-3 py-2"/>
          </div>
          <div>
            <label class="block text-sm font-medium mb-1">Harga</label>
            <input v-model="form.harga" type="number" class="w-full border rounded-lg px-3 py-2"/>
          </div>
          <div>
            <label class="block text-sm font-medium mb-1">Kategori</label>
            <select v-model="form.id_kategori" class="w-full border rounded-lg px-3 py-2">
              <option v-for="k in kategori" :value="k.id">{{ k.nama_kategori }}</option>
            </select>
          </div>
          <div>
            <label class="block text-sm font-medium mb-1">Supplier</label>
            <select v-model="form.id_supplier" class="w-full border rounded-lg px-3 py-2">
              <option v-for="s in supplier" :value="s.id">{{ s.nama_supplier }}</option>
            </select>
          </div>
        </div>
        <div class="flex gap-2 justify-end">
          <button @click="modal=false" class="px-4 py-2 border rounded-lg">Batal</button>
          <button @click="simpan" class="bg-blue-600 text-white px-4 py-2 rounded-lg">Simpan</button>
        </div>
      </div>
    </div>
  </div>`,
  data() {
    return { list: [], kategori: [], supplier: [], modal: false,
      form: { id: null, kode_barang: '', nama_barang: '', stok: 0, harga: 0, id_kategori: '', id_supplier: '' }
    };
  },
  mounted() { this.load(); },
  methods: {
    async load() {
      const [b, k, s] = await Promise.all([
        axios.get('http://localhost/UAS_WEB2/ci4/public/api/barang'),
        axios.get('http://localhost/UAS_WEB2/ci4/public/api/kategori'),
        axios.get('http://localhost/UAS_WEB2/ci4/public/api/supplier'),
      ]);
      this.list = b.data.data; this.kategori = k.data.data; this.supplier = s.data.data;
    },
    openModal(item = null) {
      this.form = item ? { ...item } : { id: null, kode_barang: '', nama_barang: '', stok: 0, harga: 0, id_kategori: '', id_supplier: '' };
      this.modal = true;
    },
    async simpan() {
      if (this.form.id) await axios.put(`http://localhost/UAS_WEB2/ci4/public/api/barang/${this.form.id}`, this.form);
      else await axios.post('http://localhost/UAS_WEB2/ci4/public/api/barang', this.form);
      this.modal = false; this.load();
    },
    async hapus(id) {
      if (confirm('Hapus barang ini?')) {
        await axios.delete(`http://localhost/UAS_WEB2/ci4/public/api/barang/${id}`);
        this.load();
      }
    }
  }
};