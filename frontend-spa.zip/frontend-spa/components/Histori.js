const HistoriComponent = {
  template: `
  <div class="p-6">
    <div class="flex justify-between items-center mb-4">
      <h2 class="text-2xl font-bold text-gray-700">📋 Histori Stok</h2>
      <button @click="openModal()" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">+ Tambah</button>
    </div>
    <div class="bg-white rounded-xl shadow overflow-x-auto">
      <table class="w-full text-sm">
        <thead class="bg-blue-600 text-white">
          <tr>
            <th class="p-3 text-left">No</th><th class="p-3 text-left">Barang</th>
            <th class="p-3 text-left">Jenis</th><th class="p-3 text-left">Jumlah</th>
            <th class="p-3 text-left">Keterangan</th><th class="p-3 text-left">Tanggal</th>
            <th class="p-3 text-left">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(item, i) in list" :key="item.id" class="border-b hover:bg-gray-50">
            <td class="p-3">{{ i+1 }}</td>
            <td class="p-3">{{ item.nama_barang }}</td>
            <td class="p-3">
              <span :class="item.jenis === 'masuk' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'" class="px-2 py-1 rounded-full text-xs font-semibold uppercase">
                {{ item.jenis }}
              </span>
            </td>
            <td class="p-3">{{ item.jumlah }}</td>
            <td class="p-3">{{ item.keterangan }}</td>
            <td class="p-3">{{ item.tanggal }}</td>
            <td class="p-3">
              <button @click="hapus(item.id)" class="bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600">Hapus</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
    <div v-if="modal" class="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div class="bg-white rounded-xl p-6 w-full max-w-md shadow-xl">
        <h3 class="text-lg font-bold mb-4">Tambah Histori Stok</h3>
        <div class="mb-3">
          <label class="block text-sm font-medium mb-1">Barang</label>
          <select v-model="form.id_barang" class="w-full border rounded-lg px-3 py-2">
            <option v-for="b in barang" :value="b.id">{{ b.nama_barang }}</option>
          </select>
        </div>
        <div class="mb-3">
          <label class="block text-sm font-medium mb-1">Jenis</label>
          <select v-model="form.jenis" class="w-full border rounded-lg px-3 py-2">
            <option value="masuk">Masuk</option>
            <option value="keluar">Keluar</option>
          </select>
        </div>
        <div class="mb-3">
          <label class="block text-sm font-medium mb-1">Jumlah</label>
          <input v-model="form.jumlah" type="number" class="w-full border rounded-lg px-3 py-2"/>
        </div>
        <div class="mb-4">
          <label class="block text-sm font-medium mb-1">Keterangan</label>
          <textarea v-model="form.keterangan" class="w-full border rounded-lg px-3 py-2"></textarea>
        </div>
        <div class="flex gap-2 justify-end">
          <button @click="modal=false" class="px-4 py-2 border rounded-lg">Batal</button>
          <button @click="simpan" class="bg-blue-600 text-white px-4 py-2 rounded-lg">Simpan</button>
        </div>
      </div>
    </div>
  </div>`,
  data() {
    return { list: [], barang: [], modal: false,
      form: { id_barang: '', jenis: 'masuk', jumlah: 1, keterangan: '' }
    };
  },
  mounted() { this.load(); },
  methods: {
    async load() {
      const [h, b] = await Promise.all([
        axios.get('http://localhost/UAS_WEB2/ci4/public/api/histori'),
        axios.get('http://localhost/UAS_WEB2/ci4/public/api/barang'),
      ]);
      this.list = h.data.data; this.barang = b.data.data;
    },
    openModal() {
      this.form = { id_barang: '', jenis: 'masuk', jumlah: 1, keterangan: '' };
      this.modal = true;
    },
    async simpan() {
      await axios.post('http://localhost/UAS_WEB2/ci4/public/api/histori', this.form);
      this.modal = false; this.load();
    },
    async hapus(id) {
      if (confirm('Hapus histori ini?')) {
        await axios.delete(`http://localhost/UAS_WEB2/ci4/public/api/histori/${id}`);
        this.load();
      }
    }
  }
};