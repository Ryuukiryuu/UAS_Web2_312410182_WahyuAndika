const DashboardComponent = {
  template: `
  <div class="p-6">
    <h2 class="text-2xl font-bold text-gray-700 mb-6">📊 Dashboard</h2>
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
      <div class="bg-blue-500 text-white rounded-xl p-5 shadow">
        <div class="text-4xl font-bold">{{ summary.total_barang }}</div>
        <div class="text-sm mt-1">Total Barang</div>
      </div>
      <div class="bg-green-500 text-white rounded-xl p-5 shadow">
        <div class="text-4xl font-bold">{{ summary.total_kategori }}</div>
        <div class="text-sm mt-1">Kategori</div>
      </div>
      <div class="bg-yellow-500 text-white rounded-xl p-5 shadow">
        <div class="text-4xl font-bold">{{ summary.total_supplier }}</div>
        <div class="text-sm mt-1">Supplier</div>
      </div>
      <div class="bg-purple-500 text-white rounded-xl p-5 shadow">
        <div class="text-4xl font-bold">{{ summary.total_histori }}</div>
        <div class="text-sm mt-1">Histori Stok</div>
      </div>
    </div>
    <p class="mt-6 text-gray-500">Selamat datang, <strong>{{ username }}</strong>!</p>
  </div>`,
  data() {
    return { summary: { total_barang: 0, total_kategori: 0, total_supplier: 0, total_histori: 0 }, username: '' };
  },
  mounted() {
    this.username = localStorage.getItem('username');
    axios.get('http://localhost/UAS_WEB2/ci4/public/api/summary')
      .then(r => this.summary = r.data.data);
  }
};