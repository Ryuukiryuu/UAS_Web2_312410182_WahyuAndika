<?php
namespace App\Controllers;
use CodeIgniter\RESTful\ResourceController;

class DashboardController extends ResourceController
{
    protected $format = 'json';

    public function summary()
    {
        $db = \Config\Database::connect();
        return $this->respond([
            'status' => 200,
            'data'   => [
                'total_barang'   => $db->table('barang')->countAllResults(),
                'total_kategori' => $db->table('kategori')->countAllResults(),
                'total_supplier' => $db->table('supplier')->countAllResults(),
                'total_histori'  => $db->table('histori_stok')->countAllResults(),
            ]
        ]);
    }
}