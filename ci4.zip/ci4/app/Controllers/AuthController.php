<?php
namespace App\Controllers;
use App\Models\UserModel;
use CodeIgniter\RESTful\ResourceController;

class AuthController extends ResourceController
{
    public function login()
    {
        $model = new UserModel();
        $username = $this->request->getJSON()->username ?? '';
        $password = $this->request->getJSON()->password ?? '';

        $user = $model->where('username', $username)
                      ->where('password', md5($password))
                      ->first();

        if (!$user) {
            return $this->respond(['status' => 401, 'message' => 'Username atau password salah'], 401);
        }

        $token = bin2hex(random_bytes(32));
        $model->update($user['id'], ['token' => $token]);

        return $this->respond([
            'status'  => 200,
            'message' => 'Login berhasil',
            'token'   => $token,
            'username'=> $user['username']
        ]);
    }

    public function logout()
    {
        $authHeader = $this->request->getHeaderLine('Authorization');
        $token = substr($authHeader, 7);
        $model = new UserModel();
        $user = $model->where('token', $token)->first();
        if ($user) $model->update($user['id'], ['token' => null]);

        return $this->respond(['status' => 200, 'message' => 'Logout berhasil']);
    }
}