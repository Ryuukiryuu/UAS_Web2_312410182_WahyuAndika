<?php
namespace App\Controllers;
use App\Models\HistoriModel;
use App\Models\BarangModel;
use CodeIgniter\RESTful\ResourceController;

class HistoriController extends ResourceController
{
    protected $modelName = HistoriModel::class;
    protected $format    = 'json';

    public function index()
    {
        return $this->respond(['status' => 200, 'data' => $this->model->getWithBarang()]);
    }

    public function create()
    {
        $data = $this->request->getJSON(true);
        $this->model->insert($data);

        // Update stok barang
        $barangModel = new BarangModel();
        $barang = $barangModel->find($data['id_barang']);
        if ($barang) {
            $stokBaru = $data['jenis'] === 'masuk'
                ? $barang['stok'] + $data['jumlah']
                : $barang['stok'] - $data['jumlah'];
            $barangModel->update($data['id_barang'], ['stok' => max(0, $stokBaru)]);
        }

        return $this->respondCreated(['status' => 201, 'message' => 'Histori berhasil ditambahkan']);
    }

    public function show($id = null)
    {
        $data = $this->model->find($id);
        return $data
            ? $this->respond(['status' => 200, 'data' => $data])
            : $this->respond(['status' => 404, 'message' => 'Data tidak ditemukan'], 404);
    }

    public function delete($id = null)
    {
        $this->model->delete($id);
        return $this->respondDeleted(['status' => 200, 'message' => 'Histori berhasil dihapus']);
    }
}