<?php
namespace App\Controllers;
use App\Models\BarangModel;
use CodeIgniter\RESTful\ResourceController;

class BarangController extends ResourceController
{
    protected $modelName = BarangModel::class;
    protected $format    = 'json';

    public function index()
    {
        return $this->respond(['status' => 200, 'data' => $this->model->getWithRelasi()]);
    }

    public function show($id = null)
    {
        $data = $this->model->find($id);
        return $data
            ? $this->respond(['status' => 200, 'data' => $data])
            : $this->respond(['status' => 404, 'message' => 'Data tidak ditemukan'], 404);
    }

    public function create()
    {
        $data = $this->request->getJSON(true);
        $this->model->insert($data);
        return $this->respondCreated(['status' => 201, 'message' => 'Barang berhasil ditambahkan']);
    }

    public function update($id = null)
    {
        $data = $this->request->getJSON(true);
        $this->model->update($id, $data);
        return $this->respond(['status' => 200, 'message' => 'Barang berhasil diupdate']);
    }

    public function delete($id = null)
    {
        $this->model->delete($id);
        return $this->respondDeleted(['status' => 200, 'message' => 'Barang berhasil dihapus']);
    }
}