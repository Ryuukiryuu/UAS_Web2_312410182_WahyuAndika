<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
// Auth
$routes->post('api/login', 'AuthController::login');
$routes->post('api/logout', 'AuthController::logout', ['filter' => 'auth']);

// Resource Routes
$routes->resource('api/kategori', ['controller' => 'KategoriController', 'filter' => 'auth']);
$routes->resource('api/supplier', ['controller' => 'SupplierController', 'filter' => 'auth']);
$routes->resource('api/barang',   ['controller' => 'BarangController',   'filter' => 'auth']);
$routes->resource('api/histori',  ['controller' => 'HistoriController',  'filter' => 'auth']);

// Public - summary untuk landing page
$routes->get('api/summary', 'DashboardController::summary');