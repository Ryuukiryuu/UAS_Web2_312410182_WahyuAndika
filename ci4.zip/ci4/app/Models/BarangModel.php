<?php
namespace App\Models;
use CodeIgniter\Model;

class BarangModel extends Model
{
    protected $table      = 'barang';
    protected $primaryKey = 'id';
    protected $allowedFields = ['kode_barang', 'nama_barang', 'stok', 'harga', 'id_kategori', 'id_supplier'];

    public function getWithRelasi()
    {
        return $this->db->table('barang b')
            ->select('b.*, k.nama_kategori, s.nama_supplier')
            ->join('kategori k', 'k.id = b.id_kategori', 'left')
            ->join('supplier s', 's.id = b.id_supplier', 'left')
            ->get()->getResultArray();
    }
}