<?php
namespace App\Models;
use CodeIgniter\Model;

class HistoriModel extends Model
{
    protected $table      = 'histori_stok';
    protected $primaryKey = 'id';
    protected $allowedFields = ['id_barang', 'jenis', 'jumlah', 'keterangan'];

    public function getWithBarang()
    {
        return $this->db->table('histori_stok h')
            ->select('h.*, b.nama_barang, b.kode_barang')
            ->join('barang b', 'b.id = h.id_barang', 'left')
            ->orderBy('h.tanggal', 'DESC')
            ->get()->getResultArray();
    }
}